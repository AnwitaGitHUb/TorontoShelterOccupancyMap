import numpy
import pandas as pd
from src import constants as c
from src.models import shelter as sc


class shelterProgram(sc.Shelter):
    def getData(self, data):
        return data

    def __init__(self, address, organizationName, name, city, postalCode, latitude, longitude,
                 program):
        super().__init__(address, organizationName, name, city, postalCode, latitude, longitude)
        self._program = program

    def calculateAverageDailyOccupancy(self, data):
        for index, row in data.iterrows():
            #print(row)
            print(self._program)
            if row["PROGRAM_NAME"] == self._program:
                dailyAverageOccupancy = sum(row[c.DATA_OCCUPANCIES]) // len(row[c.DATA_OCCUPANCIES])
                print(dailyAverageOccupancy)
                return dailyAverageOccupancy

    def calculateAverageDailyOccupancyRate(self, data):

        occ_rate_sum = 0
        count = 0  # To count valid occupancy rates
        for index, row in data.iterrows():
            if row["PROGRAM_NAME"] == self._program:
                for idx, occupancy in enumerate(row["OCCUPANCIES"]):
                    if row["CAPACITIES"][idx] != 0:
                        occ_rate_sum += occupancy / row["CAPACITIES"][idx]
                        count += 1
        if count == 0:
            return 0  # To avoid division by zero if there are no valid entries
        average_rate_sum = occ_rate_sum / count
        return average_rate_sum

    def popUpText(self, data):
        popUpText = (f"popup'> Organization Name: {self.getOrganizationName()}, Shelter Address: {self.getAddress()}, "
                     f"Name of Shelter: {self.getShelterName()}, Name of Program: {self.getProgramName()} City: {self.getCity()}, Postal Code: {self.getPostalCode()}, "
                     f" Average Annual Occupancy:{self.calculateAverageDailyOccupancy(data)}, Average Annual Rate of Occupancy:"
                     f"{self.calculateAverageDailyOccupancyRate(data)}% </div>")
        return popUpText

    def getProgramName(self):
        return self._program
