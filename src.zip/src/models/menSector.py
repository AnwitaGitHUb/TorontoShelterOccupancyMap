
import numpy as np
from src import constants as c
import folium as fl
from src.models.shelter_sector_program import shelterSectorProgram
class ProgramMen(shelterSectorProgram):
    def __init__(self, index, address, organizationName, name, city, postalCode, occupancy, capacity, latitude, longitude, sector, programName):
        super().__init__(index, address, organizationName, name, city, postalCode, occupancy, capacity, latitude, longitude, programName, sector)
    def get_marker(self, getData, type_of_map):
        if self.getSector() == "Men":
            fl.Marker(
                location = (self.getLatitude(), self.getLongitude()),
                axis = 1,
                popup=self.popUpText(getData),
                icon = self.get_icon(getData)
            ).add_to(type_of_map)
    def get_icon(self, getData):
        if self.getSector() == "Men":
            if self.quartileMenDataOccupancy(getData) >= self.calculateThirdQuartileMen(getData):
                icon = fl.Icon(prefix = "fa", color = "red", icon = "person")
                return icon
            elif self.quartileMenDataOccupancy(getData) >= self.calculateSecondQuartileMen(getData) and self.quartileMenDataOccupancy(getData) < self.calculateThirdQuartileMen(getData):
                icon = fl.Icon(prefix = "fa", color ="orange", icon="person")
                return icon
            elif self.quartileMenDataOccupancy(getData) >= self.calculateFirstQuartileMen(getData) and self.quartileMenDataOccupancy(getData) < self.calculateSecondQuartileMen(getData):
                icon = fl.Icon(prefix="fa", color = "beige", icon = "person")
                return icon
            else:
                icon = fl.Icon(prefix="fa", color = "green", icon="person")
                return icon
    def quartileMenData(self,getData):
        if self.getSector() == "Men":
             quartileMen = getData[getData["SECTOR"] == "Men"]
             quartileMen = quartileMen.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
             quartileDataMen = quartileMen.sort_values(by=["OCCUPANCY"])
             return quartileDataMen
    def quartileMenDataOccupancy(self, getData):
        if self.getSector() == "Men":
             quartile = getData[getData["SECTOR"] == "Men"]
             quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum()
             quartileMenData = quartile.sort_values(ascending=True).to_dict()
             return quartileMenData[self.getProgramName()]
    def calculateFirstQuartileMen(self,getData):
           if self.getSector() == "Men":
             secondMenQuartile = np.quantile(self.quartileMenData(getData)["OCCUPANCY"], 0.25)
             return secondMenQuartile
    def calculateSecondQuartileMen(self,getData):
        if self.getSector() == "Men":
             secondMenQuartile = np.quantile(self.quartileMenData(getData)["OCCUPANCY"], 0.50)
             return secondMenQuartile
    def calculateThirdQuartileMen(self,getData):
        if self.getSector() == "Men":
             thirdMenQuartile = np.quantile(self.quartileMenData(getData)["OCCUPANCY"], 0.75)
             return thirdMenQuartile
