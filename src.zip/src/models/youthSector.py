import numpy as np
from src import constants as c
import folium as fl
from src.models.shelter_sector_program import shelterSectorProgram


class youthShelter(shelterSectorProgram):
    def __init__(self, index, address, organizationName, name, city, postalCode, occupancy, capacity, latitude,
                 longitude, sector, programName):
        super().__init__(index, address, organizationName, name, city, postalCode, occupancy, capacity, latitude,
                         longitude, programName, sector)

    def get_icon(self, getData):
        if self.getSector() == "Youth":
            if self.sortedYouthOccupanicesDict(getData) >= self.calculateThirdQuartileYouth(getData):
                icon = fl.Icon(prefix="fa", color="red", icon="child")
                return icon
            elif self.sortedYouthOccupanicesDict(getData) >= self.calculateSecondQuartileYouth(
                    getData) and self.sortedYouthOccupanicesDict(getData) < self.calculateThirdQuartileYouth(getData):
                icon = fl.Icon(prefix="fa", color="orange", icon="child")
                return icon
            elif self.sortedYouthOccupanicesDict(getData) >= self.calculateFirstQuartileYouth(
                    getData) and self.sortedYouthOccupanicesDict(getData) < self.calculateSecondQuartileYouth(getData):
                icon = fl.Icon(prefix="fa", color="beige", icon="child")
                return icon
            else:
                icon = fl.Icon(prefix="fa", color="green", icon="child")
                return icon

    def sortedYouthOccupancies(self, getData):
        if self.getSector() == "Youth":
            quartileYouth = getData[getData["SECTOR"] == "Youth"]
            quartileYouth = quartileYouth.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
            quartileDataYouth = quartileYouth.sort_values(by=["OCCUPANCY"])
            return quartileDataYouth

    def sortedYouthOccupanicesDict(self, getData):
        if self.getSector() == "Youth":
            quartile = getData[getData["SECTOR"] == "Youth"]
            quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum()
            quartileYouthData = quartile.sort_values(ascending=True).to_dict()
            return quartileYouthData[self.getProgramName()]

    def calculateFirstQuartileYouth(self, getData):
        if self.getSector() == "Youth":
            firstYouthQuartile = np.quantile(self.sortedYouthOccupancies(getData)["OCCUPANCY"], 0.25)
            return firstYouthQuartile

    def calculateSecondQuartileYouth(self, getData):
        if self.getSector() == "Youth":
            secondYouthQuartile = np.quantile(self.sortedYouthOccupancies(getData)["OCCUPANCY"], 0.50)
            return secondYouthQuartile

    def calculateThirdQuartileYouth(self, getData):
        if self.getSector() == "Youth":
            thirdYouthQuartile = np.quantile(self.sortedYouthOccupancies(getData)["OCCUPANCY"], 0.75)
            return thirdYouthQuartile

    def addToMap(self, getData, type_of_map):
        if self.getSector() == "Youth":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(getData),
                icon=self.youthIcon(getData)).add_to(type_of_map)
