import pandas as pd
import pgeocode
import numpy as np
import folium as fl
from src import constants as c
class Shelter():
    """
    A shelter object that holds information regarding its background information, such as its location, sector of people
    which it serves, information regarding the organization it belongs to, as well changing data regarding
    its occupancy. It can also calculate different types of averages with its occupancy data, including annual
    average occupancy, and annual average rate of occupancy.

    Attributes
    ----------
    index : int
           The index of the row of the shelter object in the dataset
    organizationName : str
           The name of the organization that runs the shelter - this is different from the name of the shelter
    name : str
           The name of the shelter
    address : str
           The address of the shelter
    city : str
           The name of the city in which the shelter resides
    postalCode : str
           The postal code of the shelter (different from address)
    occupancy : int
           The number of people who occupy a shelter on a given day
    capacity : int
           The maximu number of homeless residents the shelter can host on a given day

    Methods
    -------
    calculateAveragedDailyOccupancy() -> int
                    The daily average of the number of people who occupy a given shelter every day throughout 2020
    calculateAverageDailyOccupancyRate() -> float
                    The daily average of the percentage of occupancy of a given shelter over the year
    popUpText() -> str
                    Creates a message including the shelter's information such as name, city, etc.
    addMap() -> void
                    Adds/displays the icon of the shelter to the map
    getIndex() -> int
                    Returns the index value of the shelter in the dataset
    getAddress() -> str
                    Returns the address of the shelter
    getOrganizationName() -> str
                    Returns the name of the shelter's organization
    getShelterName() -> str
                    Returns the name of the shelter
    getCity() -> str
                    Returns the name of the city that the shelter is in
    getPostalCode() -> str
                    Returns the postal code of the shelter
    getLongitude() -> float
                    Returns the longitude of the shelter
    getLatitude() -> float
                    Returns the latitude of the shelter


     """

    def __init__(self, address, organizationName, name , city, postalCode,  latitude, longitude):
        """
        Constructor to build a shelter object

        Parameters
        ----------

        index: int
               The index of the shelter with regards to the row of the dataset
        organization_name: str
               The name of the organization which owns the shelter
        name: str
               The name of the shelter
        address: str
               The adress of the shelter
        city: str
              The city which the shelter is located in
        postalCode: str
              The postal code of the shelter
        occupancy: int
              The number of people who are occupying the shelter on a given date
        capacity: int
              The maximum number of people who are allowed to occupy a shelter on a given date
        """

        self._address = address
        self._organization = organizationName
        self._name = name
        self._city = city
        self._postalCode = postalCode
        self._latitude = latitude
        self._longitude = longitude
    def calculateAverageDailyOccupancy(self, data):
        '''
        Calculates average daily occupancy of a shelter over the year

        Parameters
        ----------

        data : dict
               The dataframe which contains the shelter data.

        Returns
        ------ -
        int
            The average daily occupancy of a shelter over the year

        '''
        average_occ_sum = 0
        numberOfShelters = 0
        for row in data.iterrows():
            if row["POSTAL_CODE"] == self._postalCode:
                occu_sum = sum(row["OCCUPANCIES"])
                average_occ_sum += occu_sum/len(row["OCCUPANCIES"])
                numberOfShelters +=1
        average_occ_sum/= numberOfShelters
        average_occ_sum = average_occ_sum * 100
        return average_occ_sum





    def calculateAverageDailyOccupancyRate(self, data):
        '''
        Calculates the average daily percentage of occupancy of a shelter over the year

        Parameters
        ----------

        data : dict
                The dataframe which contains the shelter data.

        Returns
        -------
        float
            The value of the average daily rate of occupancy for the shelter
        '''
        occupancies_rate_sum = 0
        numShelters_ = 0
        for row in data.iterrows():
            if row[c.DATA_POSTAL_CODE] == self._postalCode:
                occ_rate = 0
                for index in row["OCCUPANCIES"]:
                   occ_rate += row["OCCUPANCIES"][index]/ row["CAPACITIES"][index]
                   occupancies_rate_sum += occ_rate
            numShelters_ +=1
        occupancies_rate_sum = (occupancies_rate_sum/numShelters_) *100

        print(occupancies_rate_sum)
        return occupancies_rate_sum

    def popUpText(self, data):
        popUpText= (f"Organization Name: {self.getOrganizationName()}, Shelter Address: {self.getAddress()}, "
                    f"Name of Shelter: {self.getShelterName()}, City: {self.getCity()}, Postal Code: {self.getPostalCode()}, "
                    f" Average Annual Occupancy:{self.calculateAverageDailyOccupancy(data)}, Average Annual Rate of Occupancy:"
                    f"{self.calculateAverageDailyOccupancyRate(data)}% ")
        return popUpText
    def addToMap(self, data, map):
        fl.Marker(
        location=(self.getLatitude(), self.getLongitude()),
        popup= self.popUpText(data),
        axis = 1
    ).add_to(map)

    def getAddress(self):
        return self._address
    def getOrganizationName(self):
        return self._organization
    def getShelterName(self):
        return self._name
    def getCity(self):
        return self._city
    def getPostalCode(self):
        return self._postalCode
    def getLongitude(self):
        return self._longitude
    def getLatitude(self):
        return self._latitude






