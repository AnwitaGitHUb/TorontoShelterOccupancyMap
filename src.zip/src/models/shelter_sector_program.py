import folium as fl
import numpy as np
from src import constants as c
from src.models import shelter_program as spc


class shelterSectorProgram(spc.shelterProgram):

    def __init__(self, address, organizationName, name, city, postalCode, latitude,
                 longitude, sector, programName):
        super().__init__(address, organizationName, name, city, postalCode, latitude,
                         longitude, programName)
        self._sector = sector

    def getData(self, data):
        return data

    def addToMap(self, data, type_of_map):
        if self.getSector() == "Women":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(data),
                icon=fl.Icon(prefix="fa", color="pink", icon="person-dress")).add_to(type_of_map)
        if self.getSector() == "Men":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(data),
                icon=fl.Icon(prefix="fa", color="blue", icon="person")).add_to(type_of_map)
        if self.getSector() == "Youth":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(data),
                icon=fl.Icon(prefix="fa", color="orange", icon="child")
            ).add_to(type_of_map)
        if self.getSector() == "Co-ed":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(data),
                icon=fl.Icon(prefix="fa", color="purple", icon="children")
            ).add_to(type_of_map)
        if self.getSector() == "Families":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(data),
                icon=fl.Icon(prefix="fa", color="beige", icon="people-group")
            ).add_to(type_of_map)

    def womenMap(self, data, type_of_map):
        if self.getSector() == "Women":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(data),
                icon=self.womenIcon(data)
            ).add_to(type_of_map)

    def menMap(self, data, type_of_map):
        if self.getSector() == "Men":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(data),
                icon=self.menIcon(data)
            ).add_to(type_of_map)

    def youthMap(self, data, type_of_map):
        if self.getSector() == "Youth":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(data),
                icon=self.youthIcon(data)).add_to(type_of_map)

    def coMap(self, data, type_of_map):
        if self.getSector() == "Co-ed":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(data),
                icon=self.coicon(data)
            ).add_to(type_of_map)

    def getSector(self):
        return self._sector

    def quartileWomenData(self, data):
        quartileWomen = data[data["SECTOR"] == "Women"]
        quartileWomen = quartileWomen.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
        quartileDataWomen = quartileWomen.sort_values(by=["OCCUPANCY"])
        return quartileDataWomen

    def quartileWomenDataOccupancy(self, data):
        if self.getSector() == "Women":
            quartile = data[data["SECTOR"] == "Women"]
            quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum()
            quartileWomenData = quartile.sort_values(ascending=True).to_dict()
            return quartileWomenData[self.getProgramName()]

    def quartileData(self, data):
        quartileWomen = data[data["SECTOR"] == "Women"]
        quartileWomen = quartileWomen.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
        quartileDataWomen = quartileWomen.sort_values(by=["OCCUPANCY"])
        return quartileDataWomen

    def quartileDataOccupancy(self, data):
        if self.getSector() == "Women":
            quartile = data[data["SECTOR"] == "Women"]
            quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum()
            quartileWomenData = quartile.sort_values(ascending=True).to_dict()
            return quartileWomenData[self.getProgramName()]

    def calculateFirstQuartileWomen(self, data):
        if self.getSector() == "Women":
            firstQuartile = np.quantile(self.quartileWomenData(data)["OCCUPANCY"], 0.25)
            return firstQuartile

    def calculateSecondQuartileWomen(self, data):
        if self.getSector() == "Women":
            secondQuartile = np.quantile(self.quartileWomenData(data)["OCCUPANCY"], 0.50)
            return secondQuartile

    def calculateThirdQuartileWomen(self, data):
        if self.getSector() == "Women":
            firstQuartile = np.quantile(self.quartileWomenData(data)["OCCUPANCY"], 0.75)
            return firstQuartile

    def calculateFirstQuartile(self, data):
        if self.getSector() == "Women":
            firstQuartile = np.quantile(self.quartileWomenData(data)["OCCUPANCY"], 0.25)
            return firstQuartile

    def calculateSecondQuartile(self, data):
        if self.getSector() == "Women":
            secondQuartile = np.quantile(self.quartileWomenData(data)["OCCUPANCY"], 0.50)
            return secondQuartile

    def calculateThirdQuartile(self, data):
        if self.getSector() == "Women":
            firstQuartile = np.quantile(self.quartileWomenData(data)["OCCUPANCY"], 0.75)
            return firstQuartile

    def quartileMenData(self, data):
        if self.getSector() == "Men":
            quartileMen = data[data["SECTOR"] == "Men"]
            quartileMen = quartileMen.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
            quartileDataMen = quartileMen.sort_values(by=["OCCUPANCY"])
            return quartileDataMen

    def quartileMenDataOccupancy(self, data):
        if self.getSector() == "Men":
            quartile = data[data["SECTOR"] == "Men"]
            quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum()
            quartileMenData = quartile.sort_values(ascending=True).to_dict()
            return quartileMenData[self.getProgramName()]

    def calculateFirstQuartileMen(self, data):
        if self.getSector() == "Men":
            firstMenQuartile = np.quantile(self.quartileMenData(data)["OCCUPANCY"], 0.25)
            return firstMenQuartile

    def calculateSecondQuartileMen(self, data):
        if self.getSector() == "Men":
            secondMenQuartile = np.quantile(self.quartileMenData(data)["OCCUPANCY"], 0.50)
            return secondMenQuartile

    def calculateThirdQuartileMen(self, data):
        if self.getSector() == "Men":
            thirdMenQuartile = np.quantile(self.quartileMenData(data)["OCCUPANCY"], 0.75)
            return thirdMenQuartile

    def quartileCoData(self, data):
        if self.getSector() == "Co-ed":
            quartileCo = data[data["SECTOR"] == "Co-ed"]
            quartileCo = quartileCo.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
            quartileDataCo = quartileCo.sort_values(by=["OCCUPANCY"])
            return quartileDataCo

    def quartileCoDataOccupancy(self, data):
        if self.getSector() == "Co-ed":
            quartile = data[data["SECTOR"] == "Co-ed"]
            quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum()
            quartileCoData = quartile.sort_values(ascending=True).to_dict()
            return quartileCoData[self.getProgramName()]

    def calculateFirstQuartileCo(self, data):
        if self.getSector() == "Co-ed":
            firstCoQuartile = np.quantile(self.quartileCoData(data)["OCCUPANCY"], 0.25)
            return firstCoQuartile

    def calculateSecondQuartileCo(self, data):
        if self.getSector() == "Co-ed":
            secondCoQuartile = np.quantile(self.quartileCoData(data)["OCCUPANCY"], 0.50)
            return secondCoQuartile

    def calculateThirdQuartileCo(self, data):
        if self.getSector() == "Co-ed":
            thirdCoQuartile = np.quantile(self.quartileCoData(data)["OCCUPANCY"], 0.75)
            return thirdCoQuartile

    def quartileYouthData(self, data):
        if self.getSector() == "Youth":
            quartileYouth = data[data["SECTOR"] == "Youth"]
            quartileYouth = quartileYouth.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
            quartileDataYouth = quartileYouth.sort_values(by=["OCCUPANCY"])
            return quartileDataYouth

    def quartileYouthDataOccupancy(self, data):
        if self.getSector() == "Youth":
            quartile = data[data["SECTOR"] == "Youth"]
            quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum()
            quartileYouthData = quartile.sort_values(ascending=True).to_dict()
            return quartileYouthData[self.getProgramName()]

    def calculateFirstQuartileYouth(self, data):
        if self.getSector() == "Youth":
            firstYouthQuartile = np.quantile(self.quartileYouthData(data)["OCCUPANCY"], 0.25)
            return firstYouthQuartile

    def calculateSecondQuartileYouth(self, data):
        if self.getSector() == "Youth":
            secondYouthQuartile = np.quantile(self.quartileYouthData(data)["OCCUPANCY"], 0.50)
            return secondYouthQuartile

    def calculateThirdQuartileYouth(self, data):
        if self.getSector() == "Youth":
            thirdYouthQuartile = np.quantile(self.quartileYouthData(data)["OCCUPANCY"], 0.75)
            return thirdYouthQuartile

    def womenIcon(self, data):
        if self.getSector() == "Women":
            if self.quartileWomenDataOccupancy(data) >= self.calculateThirdQuartileWomen(data):
                icon = fl.Icon(prefix="fa", color="red", icon="person-dress")
                return icon
            elif self.calculateSecondQuartileWomen(
                    data) <= self.quartileWomenDataOccupancy(data) < self.calculateThirdQuartileWomen(data):
                icon = fl.Icon(prefix="fa", color="orange", icon="person-dress")
                return icon
            elif self.calculateFirstQuartileWomen(
                    data) <= self.quartileWomenDataOccupancy(data) < self.calculateSecondQuartileWomen(data):
                icon = fl.Icon(prefix="fa", color="beige", icon="person-dress")
                return icon
            else:
                icon = fl.Icon(prefix="fa", color="green", icon="person-dress")
                return icon

    def menIcon(self, data):
        if self.getSector() == "Men":
            if self.quartileMenDataOccupancy(data) >= self.calculateThirdQuartileMen(data):
                icon = fl.Icon(prefix="fa", color="red", icon="person")
                return icon
            elif self.calculateSecondQuartileMen(
                    data) <= self.quartileMenDataOccupancy(data) < self.calculateThirdQuartileMen(data):
                icon = fl.Icon(prefix="fa", color="orange", icon="person")
                return icon
            elif self.calculateFirstQuartileMen(
                    data) <= self.quartileMenDataOccupancy(data) < self.calculateSecondQuartileMen(data):
                icon = fl.Icon(prefix="fa", color="beige", icon="person")
                return icon
            else:
                icon = fl.Icon(prefix="fa", color="green", icon="person")
                return icon

    def coicon(self, data):
        if self.getSector() == "Co-ed":
            if self.quartileCoDataOccupancy(data) >= self.calculateThirdQuartileCo(data):
                icon = fl.Icon(prefix="fa", color="red", icon="children")
                return icon
            elif self.calculateSecondQuartileCo(
                    data) <= self.quartileCoDataOccupancy(data) < self.calculateThirdQuartileCo(data):
                icon = fl.Icon(prefix="fa", color="orange", icon="children")
                return icon
            elif self.calculateFirstQuartileCo(
                    data) <= self.quartileCoDataOccupancy(data) < self.calculateSecondQuartileCo(data):
                icon = fl.Icon(prefix="fa", color="beige", icon="children")
                return icon
            else:
                icon = fl.Icon(prefix="fa", color="green", icon="children")
                return icon

    def youthIcon(self, data):
        if self.getSector() == "Youth":
            if self.quartileYouthDataOccupancy(data) >= self.calculateThirdQuartileYouth(data):
                icon = fl.Icon(prefix="fa", color="red", icon="child")
                return icon
            elif self.calculateSecondQuartileYouth(
                    data) <= self.quartileYouthDataOccupancy(data) < self.calculateThirdQuartileYouth(data):
                icon = fl.Icon(prefix="fa", color="orange", icon="child")
                return icon
            elif self.calculateFirstQuartileYouth(
                    data) <= self.quartileYouthDataOccupancy(data) < self.calculateSecondQuartileYouth(data):
                icon = fl.Icon(prefix="fa", color="beige", icon="child")
                return icon
            else:
                icon = fl.Icon(prefix="fa", color="green", icon="child")
                return icon
