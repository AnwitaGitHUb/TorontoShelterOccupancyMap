import random
import time

import numpy
import pandas as pd
from src import constants as c
from src.models import shelter_program as spc
import folium as fl
import timeit
from datetime import datetime


class weatherShelter(spc.shelterProgram):
    def __init__(self, address, organizationName, name, city, postalCode, latitude,
                 longitude, weather, programName):
        super().__init__( address, organizationName, name, city, postalCode, latitude,
                         longitude, programName)
        self._weather = weather

    def addToMap(self, getData, type_of_map):
        if self.getWeather() == True:
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(getData),
                icon=fl.Icon(prefix="fa", color="blue", icon="cloud")
            ).add_to(type_of_map)
        else:
            if self.getWeather() == False:
                fl.Marker(
                    location=(self.getLatitude(), self.getLongitude()),
                    axis=1,
                    popup=self.popUpText(getData),
                    icon=fl.Icon(prefix="fa", color="red", icon="person-shelter")
                ).add_to(type_of_map)

    def addWeatherShelter(self, getData, type_of_map):
        if self.getWeather() == True:
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(getData),
                icon=self.createicon(getData)
            ).add_to(type_of_map)

    def getWeather(self):
        return self._weather

    def insertionSort(self, getData):
        for x in range(1, len(getData)):
            key = getData[x]
            previousIndex = x - 1
            while previousIndex >= 0 and getData[previousIndex] > key:
                getData[previousIndex + 1] = getData[previousIndex]
                previousIndex -= 1
            getData[previousIndex + 1] = key
        return getData

    def partition(self, getData, start, end):
        pivot = getData[end]
        lowerbound = start - 1
        for x in range(start, end):
            if getData[x] <= pivot:
                lowerbound += 1
                getData[lowerbound], getData[x] = getData[x], getData[lowerbound]
        getData[lowerbound + 1], getData[end] = getData[end], getData[lowerbound + 1]
        return lowerbound + 1

    def quickSort(self, getData, start, end):
        if start < end:
            partition = self.partition(getData, start, end)
            self.quickSort(getData, start, partition - 1)
            self.quickSort(getData, partition + 1, end)
        return getData

    def sortedOccupancyData(self, getData):
        if self.getWeather() == True:
            quartile = getData[getData["WEATHER"] == True]
            quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
            quartile = quartile["OCCUPANCY"].tolist()
            quartileData = self.insertionSort(quartile)
            quartileData = self.quickSort(quartile, 0, (len(quartile) - 1))
            return quartileData

    def linearSearch(self, quartileData, getDataValue):
        for x in range(((len(quartileData)) - 1)):
            if quartileData[x] == getDataValue:
                return x

    start = time.perf_counter_ns()

    end = time.perf_counter_ns()
    print(end - start)

    def sortedOuccpancyData(self, getData):
        if self.getWeather() == True:
            quartile = getData[getData["WEATHER"] == True]
            quartileData = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().to_dict()
            quartileDataOccupancy = self.linearSearch(self.sortedOccupancyData(getData),
                                                      quartileData[self.getProgramName()])

    def firstQuartile(self, getData):
        if self.getWeather() == True:
            return 0.25 * ((len(self.sortedOccupancyData(getData))) - 1)

    def secondQuartile(self, getData):
        if self.getWeather() == True:
            return 0.50 * ((len(self.sortedOccupancyData(getData))) - 1)

    def thirdQuartile(self, getData):
        if self.getWeather() == True:
            return 0.75 * ((len(self.sortedOccupancyData(getData))) - 1)

    def createicon(self, getData):
        if self.getWeather() == True:
            if self.sortedOuccpancyData(getData) >= self.thirdQuartile(getData):
                icon = fl.Icon(prefix="fa", color="red", icon="cloud")
                return icon
            elif self.sortedOuccpancyData(getData) >= self.secondQuartile(getData) and self.sortedOuccpancyData(
                    getData) < self.thirdQuartile(getData):
                icon = fl.Icon(prefix="fa", color="orange", icon="cloud")
                return icon
            elif self.sortedOuccpancyData(getData) >= self.firstQuartile(getData) and self.sortedOuccpancyData(
                    getData) < self.secondQuartile(getData):
                icon = fl.Icon(prefix="fa", color="beige", icon="cloud")
                return icon
            else:
                icon = fl.Icon(prefix="fa", color="green", icon="cloud")
                return icon
