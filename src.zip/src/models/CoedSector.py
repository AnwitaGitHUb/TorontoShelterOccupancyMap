import numpy as np
from src import constants as c
import folium as fl
from src.models.shelter_sector_program import shelterSectorProgram


class CoedShelter(shelterSectorProgram):
    def __init__(self, index, address, organizationName, name, city, postalCode, occupancy, capacity, latitude,
                 longitude, sector, programName):
        super().__init__(index, address, organizationName, name, city, postalCode, occupancy, capacity, latitude,
                         longitude, programName, sector)

    def addToMap(self, getData, type_of_map):
        if self.getSector() == "Co-ed":
            fl.Marker(
                location=(self.getLatitude(), self.getLongitude()),
                axis=1,
                popup=self.popUpText(getData),
                icon=self.createcoicon(getData).add_to(type_of_map))

    def sortedOccupancyCoData(self, getData):
        if self.getSector() == "Co-ed":
            # quartileCo = getData[getData["SECTOR"] == "Co-ed"]
            # quartileCo = quartileCo.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
            # quartileDataCo = quartileCo.sort_values(by=["OCCUPANCY"])

            return

    def sortedDictCoDataOccupancy(self, getData):
        if self.getSector() == "Co-ed":
            quartile = getData[getData["SECTOR"] == "Co-ed"]
            quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum()
            quartileCoData = quartile.sort_values(ascending=True).to_dict()
            return quartileCoData[self.getProgramName()]

    def calculateFirstQuartileCo(self, getData):
        if self.getSector() == "Co-ed":
            firstCoQuartile = np.quantile(self.sortedOccupancyCoData(getData)["OCCUPANCY"], 0.25)
            return firstCoQuartile

    def calculateSecondQuartileCo(self, getData):
        if self.getSector() == "Co-ed":
            secondCoQuartile = np.quantile(self.sortedOccupancyCoData(getData)["OCCUPANCY"], 0.50)
            return secondCoQuartile

    def calculateThirdQuartileCo(self, getData):
        if self.getSector() == "Co-ed":
            thirdCoQuartile = np.quantile(self.sortedOccupancyCoData(getData)["OCCUPANCY"], 0.75)
            return thirdCoQuartile

    def createcoicon(self, getData):
        if self.getSector() == "Co-ed":
            if self.sortedDictCoDataOccupancy(getData) >= self.calculateThirdQuartileCo(getData):
                icon = fl.Icon(prefix="fa", color="red", icon="children")
                return icon
            elif self.sortedDictCoDataOccupancy(getData) >= self.calculateSecondQuartileCo(
                    getData) and self.sortedDictCoDataOccupancy(getData) < self.calculateThirdQuartileCo(getData):
                icon = fl.Icon(prefix="fa", color="orange", icon="children")
                return icon
            elif self.sortedDictCoDataOccupancy(getData) >= self.calculateFirstQuartileCo(
                    getData) and self.sortedDictCoDataOccupancy(getData) < self.calculateSecondQuartileCo(getData):
                icon = fl.Icon(prefix="fa", color="beige", icon="children")
                return icon
            else:
                icon = fl.Icon(prefix="fa", color="green", icon="children")
                return icon
