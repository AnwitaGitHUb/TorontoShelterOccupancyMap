
import numpy as np
from src import constants as c
import folium as fl
from src.models.shelter_sector_program import shelterSectorProgram
class womenShelter(shelterSectorProgram):
    def __init__(self, index, address, organizationName, name, city, postalCode, occupancy, capacity, latitude, longitude, sector, programName):
        super().__init__(index, address, organizationName, name, city, postalCode, occupancy, capacity, latitude, longitude, programName, sector)

    def addToMap(self, getData, type_of_map):
        if self.getSector() == "Women":
            fl.Marker(
                location = (self.getLatitude(), self.getLongitude()),
                axis = 1,
                popup=self.popUpText(getData),
                icon = self.get_icon(getData)
            ).add_to(type_of_map)
    def sortedWomenData(self, getData):
             quartileWomen = getData[getData["SECTOR"] == "Women"]
           #  quartileWomen = quartileWomen.groupby("PROGRAM_NAME")["OCCUPANCY"].sum().reset_index()
             quartileDataWomen = quartileWomen
             return quartileDataWomen
    def sortedWomenDataOccupancyDict(self, getData):
        if self.getSector() == "Women":
             quartile = getData[getData["SECTOR"] == "Women"]
             quartile = quartile.groupby("PROGRAM_NAME")["OCCUPANCY"].sum()
             quartileWomenData = quartile.sort_values(ascending=True).to_dict()
             return quartileWomenData[self.getProgramName()]
    def calculateFirstQuartileWomen(self,getData):
        if self.getSector() == "Women":
             firstQuartile = np.quantile(self.sortedWomenData(getData)["OCCUPANCY"], 0.25)
             return firstQuartile
    def calculateSecondQuartileWomen(self,getData):
        if self.getSector() == "Women":
             secondQuartile = np.quantile(self.sortedWomenData(getData)["OCCUPANCY"], 0.50)
             return secondQuartile
    def calculateThirdQuartileWomen(self,getData):
        if self.getSector() == "Women":
             firstQuartile = np.quantile(self.sortedWomenData(getData)["OCCUPANCY"], 0.75)
             return firstQuartile
    def get_icon(self, getData):
        if self.getSector() == "Women":
            if self.sortedWomenDataOccupancyDict(getData) >= self.calculateThirdQuartileWomen(getData):
                icon = fl.Icon(prefix = "fa", color = "red", icon = "person-dress")
                return icon
            elif self.sortedWomenDataOccupancyDict(getData) >= self.calculateSecondQuartileWomen(getData) and self.sortedWomenDataOccupancyDict(getData) < self.calculateThirdQuartileWomen(getData):
                icon = fl.Icon(prefix = "fa", color ="orange", icon="person-dress")
                return icon
            elif self.sortedWomenDataOccupancyDict(getData) >= self.calculateFirstQuartileWomen(getData) and self.sortedWomenDataOccupancyDict(getData) < self.calculateSecondQuartileWomen(getData):
                icon = fl.Icon(prefix="fa", color = "beige", icon = "person-dress")
                return icon
            else:
                icon = fl.Icon(prefix="fa", color = "green", icon="person-dress")
                return icon
    def menMap(self, getData, type_of_map):
        if self.getSector() == "Men":
            fl.Marker(
                location = (self.getLatitude(), self.getLongitude()),
                axis = 1,
                popup=self.popUpText(getData),
                icon = self.menIcon(getData)
            ).add_to(type_of_map)
