# Name: Homeless Shelter Map Visualization
# Purpose: Visualizes various homeless shelters in the area of the City of Toronto through the form of a geographical map


# importing libraries
import folium as fl
from folium.plugins import MiniMap
import pandas as pd
import pgeocode
import numpy as np
from src import constants as c

# from src.models import shelter_class as sc
# from src.models import shelter_program_class as spc
# from src.models import shelter_class_sector_program as ssc, shelter_class_weather_program as wsc
from src.models import shelter as sc
from src.models import shelter_program as spc
from src.models import shelter_class_weather_program as wsc
from src.models import shelter_sector_program as ssc
from src.utils import data_utils
from src import constants as c


def main():
    init_options()

    data = data_utils.init_data(pd, c.DATA_FILE_NAME)

    # data[c.DATA_POSTAL_CODE] = data[c.DATA_POSTAL_CODE].replace(["M5A-2N2"], "M5A 2N2")
    data2 = pd.read_json('../data/Daily shelter occupancy 2020.json')
    data2 = data2.replace(["M6J1E6"], "M6J 1E6")
    data2 = data2.replace(["M5A-2N2"], "M5A 2N2")

    # adding a new column based on an existing column - new column identifies if shelter is a weather shelter
    init_weather(data)
    init_weather(data2)

    # using pgeocode, a library which converts the postal code of a location into its geographic coordinates
    # initializing sthe country reference of postal code intepretation as Canada
    nominatim = pgeocode.Nominatim("ca")
    #     # using a pgeocode function to convert the postal code data into coordinate
    #     data2 = data2.iloc[:114]
    coordinates = data2[c.DATA_POSTAL_CODE].apply(lambda x: nominatim.query_postal_code(x))
    #     # loading map viualization
    map = fl.Map(location=(43.6532, -79.3832), zoom_start=10, )
    MiniMap(toggle_display=True).add_to(map)

    coed_marker_cluster, men_marker_cluster, sector_marker_cluster, weather_marker_cluster, weather_shelter_marker_cluster, women_shelter_marker_cluster, youth_marker_cluster = init_layers(
        map)

    # filling in "Nan" values of coordinates with 0 to ensure that no errors occur
    clean_coordinates(coordinates)

    # transferring coordinate data into
    data["Shelter_Coordinates_Latitude"] = coordinates["latitude"]
    data["Shelter_Coordinates_Longitude"] = coordinates["longitude"]
    # print(data)
    #
    # # #adding a new column based on an existing column - new column identifies if shelter is in the city of Toronto
    # # #if the city is Toronto, the value 'True' is returned, or else if it isn't, 'false' is returned
    # # #converts string to boolean
    # # data["IS_CITY_TORONTO"] = data["SHELTER_CITY"]
    # data["IS_CITY_TORONTO"] = np.where(data["IS_CITY_TORONTO"] == "Toronto", True, False)
    # #converting the date values of the dataset to a new type of date value which includes the month as a visible word
    # new_date = pd.to_datetime((data["OCCUPANCY_DATE"]))
    # data["OCCUPANCY_DATE"] = new_date.dt.strftime("%d %B %y")

    # creates a list to store the different shelter objects
    sector_shelter_list, weather_shelter_list = init_shelters(data)
    # using coordinates to display locations of different shelters on map
    for x in weather_shelter_list:
        x.addToMap(data, weather_marker_cluster)

    for x in sector_shelter_list:
        x.getData(data)
        x.addToMap(data, sector_marker_cluster)
        x.womenMap(data, women_shelter_marker_cluster)
        x.menMap(data, men_marker_cluster)
        x.youthMap(data, youth_marker_cluster)
        x.coMap(data, coed_marker_cluster)

    for x in weather_shelter_list:
        x.addWeatherShelter(data, weather_shelter_marker_cluster)

        x.createicon(data)
        """x.firstQuartile(data)
        x.secondQuartile(data)
        x.thirdQuartile(data)"""
    # exporting the map
    map.save("index.html")


def init_shelters(data):
    '''

    :param data:
    :return:
    '''
    shelter_program_list = []
    for index, row in data.iterrows():
        shelterProgramObject = spc.shelterProgram(row["SHELTER_ADDRESS"], row["ORGANIZATION_NAME"],
                                                  row[c.DATA_SHELTER_NAME], row["SHELTER_CITY"],
                                                  row[c.DATA_POSTAL_CODE],
                                                  row["Shelter_Coordinates_Latitude"],
                                                  row["Shelter_Coordinates_Longitude"],
                                                  row["PROGRAM_NAME"])
        shelter_program_list.append(shelterProgramObject)

    weather_shelter_list = []
    for index, row in data.iterrows():
        # loops through the different values in a row and assigns them to a new shelter object
        # new shelter objects are created until the looping of the dataset ends
        weatherShelterObject = wsc.weatherShelter(row["SHELTER_ADDRESS"], row["ORGANIZATION_NAME"],
                                                  row[c.DATA_SHELTER_NAME], row["SHELTER_CITY"],
                                                  row[c.DATA_POSTAL_CODE],
                                                  row["Shelter_Coordinates_Latitude"],
                                                  row["Shelter_Coordinates_Longitude"],
                                                  row["WEATHER"], row["PROGRAM_NAME"])
        # adds the newly created shelter object to the list of stored shelters
        weather_shelter_list.append(weatherShelterObject)

    sector_shelter_list = []
    for index, row in data.iterrows():
        sectorShelterObject = ssc.shelterSectorProgram(row["SHELTER_ADDRESS"], row["ORGANIZATION_NAME"],
                                                       row[c.DATA_SHELTER_NAME], row["SHELTER_CITY"],
                                                       row[c.DATA_POSTAL_CODE],
                                                       row["Shelter_Coordinates_Latitude"],
                                                       row["Shelter_Coordinates_Longitude"],
                                                       row["SECTOR"], row["PROGRAM_NAME"])
        sector_shelter_list.append(sectorShelterObject)
    return sector_shelter_list, weather_shelter_list


def clean_coordinates(coordinates):
    coordinates["latitude"] = coordinates["latitude"].fillna(0)
    coordinates["longitude"] = coordinates["longitude"].fillna(0)


def init_weather(data):
    data["WEATHER"] = data["PROGRAM_NAME"]
    data["WEATHER"] = np.where(data['WEATHER'].str.contains("Weather"), True, False)


def init_options():
    pd.set_option('display.width', None)
    # Environment settings:
    pd.set_option('display.max_column', None)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_seq_items', None)
    pd.set_option('display.max_colwidth', None)
    pd.set_option('expand_frame_repr', True)


def init_layers(map):
    # fgInitialMap = fl.FeatureGroup(name="All Shelters", show=True).add_to(map)
    fgWeatherMap = fl.FeatureGroup(name="Weather Shelters", show=True).add_to(map)
    fgSectorMap = fl.FeatureGroup(name="Shelter Sectors", show=True).add_to(map)
    fgWeatherShelterMap = fl.FeatureGroup(name="Weather Shelter Map", show=True).add_to(map)
    fgWomenShelterMap = fl.FeatureGroup(name="Women Shelter Map", show=True).add_to(map)
    fgMenShelterMap = fl.FeatureGroup(name="Men Shelter Map", show=True).add_to(map)
    fgYouthShelterMap = fl.FeatureGroup(name="Youth Shelter Map", show=True).add_to(map)
    fgCoedShelterMap = fl.FeatureGroup(name="Coed Shelter Map", show=True).add_to(map)

    fl.LayerControl().add_to(map)
    weather_marker_cluster = fl.plugins.MarkerCluster().add_to(fgWeatherMap)
    sector_marker_cluster = fl.plugins.MarkerCluster().add_to(fgSectorMap)
    weather_shelter_marker_cluster = fl.plugins.MarkerCluster().add_to(fgWeatherShelterMap)
    women_shelter_marker_cluster = fl.plugins.MarkerCluster().add_to(fgWomenShelterMap)
    men_marker_cluster = fl.plugins.MarkerCluster().add_to(fgMenShelterMap)
    youth_marker_cluster = fl.plugins.MarkerCluster().add_to(fgYouthShelterMap)
    coed_marker_cluster = fl.plugins.MarkerCluster().add_to(fgCoedShelterMap)

    return coed_marker_cluster, men_marker_cluster, sector_marker_cluster, weather_marker_cluster, weather_shelter_marker_cluster, women_shelter_marker_cluster, youth_marker_cluster


if __name__ == "__main__":
    main()
