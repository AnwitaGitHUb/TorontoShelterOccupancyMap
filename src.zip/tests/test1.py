from src.utils import data_utils
from src import constants as c


def main():
    fileName = '../data/Daily shelter occupancy 2020.json'
    data = data_utils.init_data(fileName)
    data2 = group_by_address(data)
    print()


def group_by_address(df):
    """Groups a DataFrame by a single 'ADDRESS' column, creating a dictionary of DataFrames.

    Args:
        df (pd.DataFrame): The input DataFrame.

    Returns:
        dict: A dictionary where keys are unique addresses and values are DataFrames.
    """

    grouped_df = df.groupby(c.DATA_ADDRESS)
    result = {address: group.reset_index(drop=True) for address, group in grouped_df}
    return result


if __name__ == "__main__":
    main()
